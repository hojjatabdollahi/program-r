Alice2 has now moved to its own repo

https://github.com/keiffster/alice2-y