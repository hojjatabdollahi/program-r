Braintree Viewer
=================

If you export the braintree to xml then you can use this utility to view the tree in a GUI

python3 view.py /path/to/xml/file

