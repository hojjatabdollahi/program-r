Corpus Creator
===============

Creates a spelling corpus from a given file which can then be used as input into the spelling checker

python3 corpus_creator.py input_file output_file