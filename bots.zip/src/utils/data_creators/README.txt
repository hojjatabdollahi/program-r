A suite of tools used to create mock data for the unit tests

Only really useful of the data format changes as the data is already created and stored in the unit tests


geonames.py - creates geolocation data for use in unit tests geonames module
googledata.py - creates data for use in unit testing google maps and directions modules
metoffice.py - creates unit test data for the metoffice unit tests
newsapi.py - creates unit test data for the newapi module