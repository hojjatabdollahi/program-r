#!/usr/bin/env bash

python3 aiml_to_csv.py test.aiml test2.csv
